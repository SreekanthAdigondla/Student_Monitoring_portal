const mongoose = require("mongoose");

const userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true },

    email: { type: String, required: true, unique: true },
    password: { type: String, required: true },

    role: {
      type: String,
      enum: ["student", "teacher"],
      required: true
    },

    // Student-specific fields
    rollNumber: String,
    branch: String,
    year: Number,
    cgpa: [Number],
    leetcode: String,
    codechef: String,
    codeforces: String,
    github: String,

    // Teacher-specific fields
    department: String
  },
  { timestamps: true }
);

module.exports = mongoose.model("User", userSchema);
