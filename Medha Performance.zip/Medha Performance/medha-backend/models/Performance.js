const mongoose = require("mongoose");

const performanceSchema = new mongoose.Schema(
  {
    student: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
    classroom: { type: mongoose.Schema.Types.ObjectId, ref: "Classroom" },

    academicScore: { type: Number, default: 0 },
    codingScore: { type: Number, default: 0 },
    overallScore: { type: Number, default: 0 },
    rank: Number
  },
  { timestamps: true }
);

module.exports = mongoose.model("Performance", performanceSchema);
