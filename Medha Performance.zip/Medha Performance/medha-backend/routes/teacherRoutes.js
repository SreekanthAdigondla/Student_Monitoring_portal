const express = require("express");
const router = express.Router();

const teacherController = require("../controllers/teacherController");
const authMiddleware = require("../middleware/authMiddleware");
const roleMiddleware = require("../middleware/roleMiddleware");

// Teacher Dashboard
router.get(
  "/dashboard",
  authMiddleware,
  roleMiddleware("teacher"),
  teacherController.getDashboard
);

// View students in a classroom with ranks
router.get(
  "/classroom/:id/students",
  authMiddleware,
  roleMiddleware("teacher"),
  teacherController.getClassroomStudents
);

module.exports = router;
