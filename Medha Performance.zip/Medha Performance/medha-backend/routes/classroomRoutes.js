const express = require("express");
const router = express.Router();

const classroomController = require("../controllers/classroomController");
const authMiddleware = require("../middleware/authMiddleware");
const roleMiddleware = require("../middleware/roleMiddleware");

// Teacher creates classroom
router.post(
  "/create",
  authMiddleware,
  roleMiddleware("teacher"),
  classroomController.createClassroom
);

// Student joins classroom using join code
router.post(
  "/join",
  authMiddleware,
  roleMiddleware("student"),
  classroomController.joinClassroom
);

module.exports = router;
