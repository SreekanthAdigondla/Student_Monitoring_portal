const express = require("express");
const router = express.Router();

const studentController = require("../controllers/studentController");
const authMiddleware = require("../middleware/authMiddleware");
const roleMiddleware = require("../middleware/roleMiddleware");

// Student Signup
router.post("/signup", studentController.studentSignup);

// Student Profile (protected)
router.get(
  "/profile",
  authMiddleware,
  roleMiddleware("student"),
  studentController.getProfile
);

// Student Dashboard (protected)
router.get(
  "/dashboard",
  authMiddleware,
  roleMiddleware("student"),
  studentController.getDashboard
);

// Student Update Profile (protected)
router.put(
  "/profile",
  authMiddleware,
  roleMiddleware("student"),
  studentController.updateProfile
);

module.exports = router;
