const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const dotenv = require("dotenv");

dotenv.config();
const app = express();

// Import Routes
const authRoutes = require("./routes/authRoutes");
const studentRoutes = require("./routes/studentRoutes");
const teacherRoutes = require("./routes/teacherRoutes");
const classroomRoutes = require("./routes/classroomRoutes");
const messageRoutes = require("./routes/messageRoutes");
app.use(express.json());

// Middleware
app.use(cors());
app.use(bodyParser.json());

// Mount routes
app.use("/api", authRoutes);       // For login
app.use("/api/student", studentRoutes);
app.use("/api/teacher", teacherRoutes);
app.use("/api/classroom", classroomRoutes);
app.use("/api/message", messageRoutes);

// Base route
app.get("/api", (req, res) => {
  res.send("Medha Student Monitoring API is running");
});

module.exports = app;


