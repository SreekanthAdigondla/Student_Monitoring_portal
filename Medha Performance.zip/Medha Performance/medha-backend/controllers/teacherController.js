const Classroom = require("../models/Classroom");
const Performance = require("../models/Performance");

exports.getDashboard = async (req, res) => {
  const classrooms = await Classroom.find({ teacher: req.user.id });
  res.json(classrooms);
};

exports.getClassroomStudents = async (req, res) => {
  const students = await Performance.find({ classroom: req.params.id })
    .populate("student")
    .sort({ overallScore: -1 });

  students.forEach((s, i) => (s.rank = i + 1));
  await Promise.all(students.map(s => s.save()));

  res.json(students);
};
