const Message = require("../models/Message");

exports.sendMessage = async (req, res) => {
  const msg = await Message.create({
    sender: req.user.id,
    receiver: req.body.receiverId,
    classroom: req.body.classroomId,
    message: req.body.message
  });
  res.status(201).json(msg);
};

exports.getMessages = async (req, res) => {
  const msgs = await Message.find({ receiver: req.user.id });
  res.json(msgs);
};
