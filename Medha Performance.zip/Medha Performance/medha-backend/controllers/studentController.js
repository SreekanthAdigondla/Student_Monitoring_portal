const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const User = require("../models/User");

// ---------------- Student Signup ----------------
const studentSignup = async (req, res) => {
  try {
    const { name, email, password, rollNumber, branch, year } = req.body;

    const existingUser = await User.findOne({ email });
    if (existingUser) return res.status(400).json({ message: "User already exists" });

    const hashedPassword = await bcrypt.hash(password, 10);

    const student = new User({
      role: "student",
      name,
      email,
      password: hashedPassword,
      rollNumber,
      branch,
      year
    });

    await student.save();
    res.json({ message: "Student registered successfully" });

  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server error" });
  }
};

// ---------------- Student Profile ----------------
const getProfile = async (req, res) => {
  const student = await User.findById(req.user.id);
  res.json(student);
};

// ---------------- Student Dashboard ----------------
const getDashboard = async (req, res) => {
  // Example: send joined classrooms and performance
  res.json({ message: "Dashboard data here" });
};

// ---------------- Update Profile ----------------
const updateProfile = async (req, res) => {
  const { name, branch, year } = req.body;
  const student = await User.findByIdAndUpdate(req.user.id, { name, branch, year }, { new: true });
  res.json(student);
};

module.exports = {
  studentSignup,
  getProfile,
  getDashboard,
  updateProfile
};

