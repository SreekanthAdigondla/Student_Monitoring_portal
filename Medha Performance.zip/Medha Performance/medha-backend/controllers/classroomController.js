const Classroom = require("../models/Classroom");
const Performance = require("../models/Performance");
const crypto = require("crypto");

exports.createClassroom = async (req, res) => {
  const classroom = await Classroom.create({
    name: req.body.name,
    joinCode: crypto.randomBytes(4).toString("hex"),
    teacher: req.user.id
  });
  res.status(201).json(classroom);
};

exports.joinClassroom = async (req, res) => {
  const classroom = await Classroom.findOne({ joinCode: req.body.joinCode });
  if (!classroom)
    return res.status(404).json({ message: "Invalid join code" });

  await Performance.create({
    student: req.user.id,
    classroom: classroom._id
  });

  res.json({ message: "Joined classroom successfully" });
};
