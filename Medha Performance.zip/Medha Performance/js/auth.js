function goToStudent() {
  window.location.href = "student-login.html";
}

function goToMentor() {
  window.location.href = "mentor-login.html";
}

function loginStudent(e) {
  e.preventDefault();
  window.location.href = "student.html";
}

function loginMentor(e) {
  e.preventDefault();
  window.location.href = "mentor.html";
}
